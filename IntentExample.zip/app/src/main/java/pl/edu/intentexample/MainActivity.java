package pl.edu.intentexample;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main), (view, insets) -> {
                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars());
                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom);
                    return insets;
                });

        // Explicit Intent: open our own second screen.
        findViewById(R.id.btnSecondActivity).setOnClickListener(view -> {
            Intent intent = new Intent(
                    MainActivity.this, SecondActivity.class);

            intent.putExtra("MESSAGE",
                    "Welcome to Campus Guide! Message sent from MainActivity.");

            startActivity(intent);
        });

        // Implicit Intent: open a website.
        findViewById(R.id.btnWebsite).setOnClickListener(view -> {
            Uri website = Uri.parse("https://www.android.com");
            Intent intent = new Intent(Intent.ACTION_VIEW, website);
            openExternalApp(intent);
        });

        // Optional requirement: open a location in a map app.
        findViewById(R.id.btnLocation).setOnClickListener(view -> {
            Uri location = Uri.parse(
                    "geo:50.3217,19.1949?q=50.3217,19.1949");

            Intent intent = new Intent(Intent.ACTION_VIEW, location);
            openExternalApp(intent);
        });
    }

    // Display a helpful message if no suitable app is installed.
    private void openExternalApp(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(
                    this,
                    "No app is installed to open this request.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
